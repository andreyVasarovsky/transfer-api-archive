<?php

namespace App\Service;

use App\Entity\Transaction;
use App\Entity\TransactionStatus;
use App\Exception\AccountNotFoundException;
use App\Exception\CurrencyIsNotFoundException;
use App\Exception\InvalidOperationException;
use App\Exception\NotEnoughBalanceException;
use App\Exception\TransferInvalidRecipientAccountCurrencyNotMatchException;
use App\Exception\TransferRecipientAccountIsNotExistsException;
use App\Exception\TransferSenderAccountIsNotExistsException;
use App\Helpers\Currency;
use App\Mapper\TransactionMapper;
use App\Model\IdResponse;
use App\Model\TransactionListResponse;
use App\Model\TransferFundsRequest;
use App\Repository\AccountRepository;
use App\Repository\CurrencyRepository;
use App\Repository\TransactionRepository;
use App\Repository\TransactionStatusRepository;

class AccountService
{
    public function __construct(
        private readonly TransactionStatusRepository $transactionStatusRepository,
        private readonly TransactionRepository       $transactionRepository,
        private readonly AccountRepository           $accountRepository,
        private readonly CurrencyRepository          $currencyRepository,
        private readonly Currency                    $currency,
    )
    {
    }

    public function transfer(TransferFundsRequest $request): IdResponse
    {
        if (!$this->accountRepository->existsById($request->getSenderId()))
            throw new TransferSenderAccountIsNotExistsException();
        if (!$this->accountRepository->existsById($request->getRecipientId()))
            throw new TransferRecipientAccountIsNotExistsException();
        if (!$this->currencyRepository->existsByCode($request->getCurrency()))
            throw new CurrencyIsNotFoundException();
        if ($request->getSenderId() == $request->getRecipientId())
            throw new InvalidOperationException();
        if ($request->getAmount() <= 0)
            throw new InvalidOperationException();

        $accountTo = $this->accountRepository->getById($request->getRecipientId());

        if ($accountTo->getCurrency()->getCode() != $request->getCurrency())
            throw new TransferInvalidRecipientAccountCurrencyNotMatchException();

        $accountFrom = $this->accountRepository->getById($request->getSenderId());

        $sendingAmount = $this->currency->getAmount(
            $request->getAmount(),
            $request->getCurrency(),
            $accountFrom->getCurrency()->getCode(),
            new \DateTime()
        );

        if ($accountFrom->getBalance() < $sendingAmount)
            throw new NotEnoughBalanceException();

        $sendingAmountRate = $this->currency->getRatesByDate($request->getCurrency(), new \DateTime());
        $statusEntity = $this->transactionStatusRepository
            ->getByTitle(TransactionStatusRepository::STATUS_COMPLETED);

        $transaction = (new Transaction())
            ->setAccountFrom($accountFrom)
            ->setAccountTo($accountTo)
            ->setAmountFrom($sendingAmount)
            ->setAmountTo($request->getAmount())
            ->setRates($sendingAmountRate)
            ->setStatus($statusEntity)
            ->setUpdatedAt(new \DateTimeImmutable())
            ->setCreatedAt(new \DateTimeImmutable());

        $id = $this->transactionRepository->saveAndCommit($transaction);
        $this->accountRepository->decreaseBalance($accountFrom, $sendingAmount);
        $this->accountRepository->increaseBalance($accountTo, $request->getAmount());

        return new IdResponse($id);
    }

    public function getTransactionsById(int $accountId, array $data = []): TransactionListResponse
    {
        if (!$this->accountRepository->existsById($accountId))
            throw new AccountNotFoundException();

        $limit = array_key_exists('limit', $data) ? intval($data['limit']) : 0;
        $offset = array_key_exists('offset', $data) ? intval($data['offset']) : 0;

        $transactions = TransactionMapper::map(
            $accountId,
            $this->accountRepository->getTransactionsByAccountId($accountId, $offset, $limit)
        );

        return new TransactionListResponse($transactions, 'Success', true);
    }
}