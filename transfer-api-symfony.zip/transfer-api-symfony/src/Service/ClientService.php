<?php

namespace App\Service;

use App\Exception\ClientNotFoundException;
use App\Mapper\AccountMapper;
use App\Model\AccountListResponse;
use App\Repository\ClientRepository;

class ClientService
{
    public function __construct(private readonly ClientRepository $clientRepository)
    {
    }

    public function getAccountsById(int $clientId): AccountListResponse
    {
        if (!$this->clientRepository->existsById($clientId))
            throw new ClientNotFoundException();

        $accounts = AccountMapper::map($this->clientRepository->getAccountsByClientId($clientId));

        return new AccountListResponse($accounts, 'Success', true);
    }
}