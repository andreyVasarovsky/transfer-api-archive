<?php

namespace App\Service;

use App\Entity\Currency;
use App\Exception\InvalidCurrencyCreateOrUpdateDataException;
use App\Model\CurrencyUpdateOrCreateRequest;
use App\Repository\CurrencyRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Validator\Constraints\EqualTo;


class CurrencyService
{
    public function __construct(
        private readonly CurrencyRepository     $currencyRepository,
        private readonly EntityManagerInterface $entityManager)
    {
    }

    public function updateOrCreate(CurrencyUpdateOrCreateRequest $request): Currency
    {
        if (empty($request->getCode()) || empty($request->getRates()))
            throw new InvalidCurrencyCreateOrUpdateDataException();

        $currency = $this->getCurrency($request->getCode());

        $currency->setRates($request->getRates())->setUpdatedAt(new \DateTimeImmutable());

        $this->currencyRepository->saveAndCommit($currency);

        return $currency;
    }

    public function resetRatesExcludeCodes(array $codes): int
    {
        $currenciesToReset = $this->currencyRepository->getCodesExcludeCodes($codes);
        if (!empty($currenciesToReset)) {
            foreach ($currenciesToReset as $currency) {
                $this->entityManager->persist($currency->setRates(0));
            }
            $this->entityManager->flush();

            return count($currenciesToReset);
        }

        return 0;
    }

    public function getCurrency(string $code): Currency
    {
        if ($this->currencyRepository->existsByCode($code)) {
            $currency = $this->currencyRepository->getByCode($code);
        } else {
            $currency = (new Currency())->setCode($code)->setCreatedAt(new \DateTimeImmutable());
        }

        return $currency;
    }
}