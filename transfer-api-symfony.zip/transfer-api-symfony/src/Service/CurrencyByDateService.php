<?php

namespace App\Service;

use App\Entity\Currency;
use App\Entity\CurrencyByDate;
use App\Exception\InvalidCurrencyByDateCreateOrUpdateDataException;
use App\Model\CurrencyByDateUpdateOrCreateRequest;
use App\Repository\CurrencyByDateRepository;
use App\Repository\CurrencyRepository;

class CurrencyByDateService
{
    public function __construct(
        private readonly CurrencyRepository       $currencyRepository,
        private readonly CurrencyByDateRepository $currencyByDateRepository
    )
    {
    }

    public function updateOrCreate(CurrencyByDateUpdateOrCreateRequest $request, Currency $currency = null): CurrencyByDate
    {
        if (empty($request->getCode()) || empty($request->getRates()) || empty($request->getDate()))
            throw new InvalidCurrencyByDateCreateOrUpdateDataException();

        $currencyByDate = $this->getCurrencyByDate($request->getCode(), $request->getDate(), $currency);

        $currencyByDate->setRates($request->getRates());

        $this->currencyByDateRepository->saveAndCommit($currencyByDate);

        return $currencyByDate;
    }

    public function getCurrencyByDate(string $code, string $date, Currency $currency = null): CurrencyByDate
    {
        if ($this->currencyByDateRepository->existsByCodeDate($code, $date)) {
            $currencyByDate = $this->currencyByDateRepository->getByCodeDate($code, $date);
        } else {
            if (is_null($currency))
                $currency = $this->currencyRepository->getByCode($code);
            $currencyByDate = (new CurrencyByDate())->setCurrency($currency)->setDate($date);
        }

        return $currencyByDate;
    }
}