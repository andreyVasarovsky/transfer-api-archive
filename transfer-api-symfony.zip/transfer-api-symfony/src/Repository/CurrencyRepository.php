<?php

namespace App\Repository;

use App\Entity\Currency;
use App\Exception\CurrencyIsNotFoundException;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\ORM\Query;
use Doctrine\Persistence\ManagerRegistry;

class CurrencyRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Currency::class);
    }

    public function existsByCode(string $code): bool
    {
        return !is_null($this->find($code));
    }

    public function getByCode(string $code): Currency
    {
        $currency = $this->find($code);
        if (is_null($currency))
            throw new CurrencyIsNotFoundException();

        return $currency;
    }

    public function getCodesExcludeCodes(array $codes): array
    {
        $query = $this->createQueryBuilder('c');
        $query->where($query->expr()->notIn('c.code', $codes));

        return $query->getQuery()->getResult();
    }
    public function saveAndCommit(Currency $currency): void
    {
        $this->getEntityManager()->persist($currency);
        $this->getEntityManager()->flush();
    }
}
