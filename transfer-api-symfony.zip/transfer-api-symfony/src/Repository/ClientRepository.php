<?php

namespace App\Repository;

use App\Entity\Account;
use App\Entity\Client;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

class ClientRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Client::class);
    }

    public function existsById(int $id): bool
    {
        return !is_null($this->find($id));
    }

    public function getAccountsByClientId(int $clientId)
    {
        return $this->getEntityManager()
            ->createQuery('SELECT a FROM App\Entity\Account a WHERE a.client = :clientId')
            ->setParameter('clientId', $clientId)
            ->getResult();
    }
}
