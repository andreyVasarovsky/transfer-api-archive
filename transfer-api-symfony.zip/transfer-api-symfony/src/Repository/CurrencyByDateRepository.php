<?php

namespace App\Repository;

use App\Entity\CurrencyByDate;
use App\Exception\CurrencyByDateIsNotFoundException;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

class CurrencyByDateRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, CurrencyByDate::class);
    }

    public function existsByCodeDate(string $code, string $date): bool
    {
        return !is_null($this->find(['currency' => $code, 'date' => $date]));
    }

    public function getByCodeDate(string $code, string $date): CurrencyByDate
    {
        $currency = $this->find(['currency' => $code, 'date' => $date]);
        if (is_null($currency))
            throw new CurrencyByDateIsNotFoundException();

        return $currency;
    }

    public function saveAndCommit(CurrencyByDate $currencyByDate): void
    {
        $this->getEntityManager()->persist($currencyByDate);
        $this->getEntityManager()->flush();
    }
}
