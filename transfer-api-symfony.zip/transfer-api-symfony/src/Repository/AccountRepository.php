<?php

namespace App\Repository;

use App\Entity\Account;
use App\Entity\Transaction;
use App\Exception\AccountNotFoundException;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

class AccountRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Account::class);
    }

    public function existsById(int $id): bool
    {
        return !is_null($this->find($id));
    }

    public function getById(int $id): Account
    {
        $account = $this->find($id);
        if (is_null($account))
            throw new AccountNotFoundException();

        return $account;
    }

    public function decreaseBalance(Account $account, $amount): void
    {
        $account->setBalance($account->getBalance() - $amount);
        $this->saveAndCommit($account);
    }

    public function increaseBalance(Account $account, $amount): void
    {
        $account->setBalance($account->getBalance() + $amount);
        $this->saveAndCommit($account);
    }

    public function saveAndCommit(Account $account): void
    {
        $this->getEntityManager()->persist($account);
        $this->getEntityManager()->flush();
    }

    public function getTransactionsByAccountId(int $accountId, $offset = 0, $limit = 0)
    {
        $qb = $this->getEntityManager()->createQueryBuilder();
        $qb
            ->add('select', 't')
            ->add('from', 'App\Entity\Transaction AS t')
            ->where('t.account_from = :accountId OR t.account_to = :accountId')
            ->add('orderBy', 't.created_at DESC, t.id DESC')
            ->setParameter('accountId', $accountId);
        if ($offset > 0)
            $qb->setFirstResult($offset);
        if ($limit > 0)
            $qb->setMaxResults($limit);

        return $qb->getQuery()->getResult();
    }
}
