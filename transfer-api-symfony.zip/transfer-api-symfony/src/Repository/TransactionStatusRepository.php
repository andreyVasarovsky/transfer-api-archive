<?php

namespace App\Repository;

use App\Entity\TransactionStatus;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

class TransactionStatusRepository extends ServiceEntityRepository
{
    const STATUS_NEW = 'New';
    const STATUS_PENDING = 'Pending';
    const STATUS_COMPLETED = 'Completed';
    const STATUS_CANCELED = 'Canceled';


    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, TransactionStatus::class);
    }

    public function getByTitle(string $title)
    {
        return $this->findOneBy(['title' => $title]);
    }
}
