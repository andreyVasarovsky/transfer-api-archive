<?php

namespace App\Model;

use OpenApi\Attributes as OA;

class ErrorResponse
{
    public function __construct(
        private readonly string $message,
        private readonly ?array $details = null,
        private readonly bool   $status = false
    )
    {
    }

    public function getStatus(): bool
    {
        return $this->status;
    }

    public function getMessage(): string
    {
        return $this->message;
    }

    #[OA\Property(type: 'any', nullable: true)]
    public function getDetails(): ?array
    {
        return $this->details;
    }
}