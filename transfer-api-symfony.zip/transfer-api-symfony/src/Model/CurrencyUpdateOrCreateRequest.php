<?php

namespace App\Model;

use Symfony\Component\Validator\Constraints\NotBlank;

class CurrencyUpdateOrCreateRequest
{
    #[NotBlank]
    private string $code;

    #[NotBlank]
    private float $rates;

    public function getCode(): string
    {
        return $this->code;
    }

    public function setCode(string $code): CurrencyUpdateOrCreateRequest
    {
        $this->code = $code;
        return $this;
    }

    public function getRates(): float
    {
        return $this->rates;
    }

    public function setRates(float $rates): CurrencyUpdateOrCreateRequest
    {
        $this->rates = $rates;
        return $this;
    }
}