<?php

namespace App\Model;

use Symfony\Component\Validator\Constraints\NotBlank;

class CurrencyByDateUpdateOrCreateRequest
{
    #[NotBlank]
    private string $code;

    #[NotBlank]
    private string $date;

    #[NotBlank]
    private float $rates;

    public function getCode(): string
    {
        return $this->code;
    }

    public function setCode(string $code): CurrencyByDateUpdateOrCreateRequest
    {
        $this->code = $code;
        return $this;
    }

    public function getRates(): float
    {
        return $this->rates;
    }

    public function setRates(float $rates): CurrencyByDateUpdateOrCreateRequest
    {
        $this->rates = $rates;
        return $this;
    }

    public function getDate(): string
    {
        return $this->date;
    }

    public function setDate(string $date): CurrencyByDateUpdateOrCreateRequest
    {
        $this->date = $date;

        return $this;
    }
}