<?php

namespace App\Model;

class DefaultListResponse
{
    public function __construct(
        private readonly array  $items,
        private readonly string $message,
        private readonly bool   $status)
    {
    }

    public function getMessage(): string
    {
        return $this->message;
    }

    public function getStatus(): bool
    {
        return $this->status;
    }

    public function getItems(): array
    {
        return $this->items;
    }
}