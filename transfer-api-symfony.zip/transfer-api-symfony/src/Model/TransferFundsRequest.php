<?php

namespace App\Model;

use Symfony\Component\Validator\Constraints\Type;
use Symfony\Component\Serializer\Annotation\Groups;
use Symfony\Component\Validator\Constraints as Assert;

class TransferFundsRequest
{
    #[Groups(["default", "create"])]
    #[Assert\NotBlank(groups: ["default", "create"])]
    #[Type('numeric')]
    private int $sender_id;

    #[Groups(["default", "create"])]
    #[Assert\NotBlank(groups: ["default", "create"])]
    #[Type('numeric')]
    private int $recipient_id;

    #[Groups(["default", "create"])]
    #[Assert\NotBlank(groups: ["default", "create"])]
    #[Type('numeric')]
    private string $amount;

    #[Groups(["default", "create"])]
    #[Assert\NotBlank(groups: ["default", "create"])]
    #[Type('string')]
    private string $currency;

    public function getSenderId(): int
    {
        return $this->sender_id;
    }

    public function setSenderId(int $sender_id): self
    {
        $this->sender_id = $sender_id;

        return $this;
    }

    public function getRecipientId(): int
    {
        return $this->recipient_id;
    }

    public function setRecipientId(int $recipient_id): self
    {
        $this->recipient_id = $recipient_id;

        return $this;
    }

    public function getAmount(): string
    {
        return $this->amount;
    }

    public function setAmount(string $amount): self
    {
        $this->amount = $amount;

        return $this;
    }

    public function getCurrency(): string
    {
        return $this->currency;
    }

    public function setCurrency(string $currency): self
    {
        $this->currency = $currency;

        return $this;
    }
}