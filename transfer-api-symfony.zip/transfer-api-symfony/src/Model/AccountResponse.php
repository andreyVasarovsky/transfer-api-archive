<?php

namespace App\Model;

class AccountResponse
{
    private ?int $id;
    private float $balance;
    private string $currency;

    public function getId(): int
    {
        return $this->id;
    }

    public function setId(?int $id): AccountResponse
    {
        $this->id = $id;

        return $this;
    }

    public function getCurrency(): string
    {
        return $this->currency;
    }

    public function setCurrency(string $currency): AccountResponse
    {
        $this->currency = $currency;

        return $this;
    }

    public function getBalance(): float
    {
        return $this->balance;
    }

    public function setBalance(float $balance): AccountResponse
    {
        $this->balance = $balance;

        return $this;
    }

}