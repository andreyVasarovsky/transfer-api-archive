<?php

namespace App\Model;

class TransactionResponse
{
    private ?int $id;
    private string $type;
    private string $status;
    private float $amount;
    private int $account_from;
    private int $account_to;
    private string $client_from;
    private string $client_to;
    private string $currency_sent;
    private string $currency_received;
    private string $date;
    private int $timestamp;


    public function getId(): int
    {
        return $this->id;
    }

    public function setId(?int $id): TransactionResponse
    {
        $this->id = $id;

        return $this;
    }

    public function getType(): string
    {
        return $this->type;
    }

    public function setType(string $type): TransactionResponse
    {
        $this->type = $type;

        return $this;
    }

    public function getStatus(): string
    {
        return $this->status;
    }

    public function setStatus(string $status): TransactionResponse
    {
        $this->status = $status;

        return $this;
    }

    public function getAmount(): float
    {
        return $this->amount;
    }

    public function setAmount(float $amount): TransactionResponse
    {
        $this->amount = $amount;

        return $this;
    }

    public function getAccountFrom(): int
    {
        return $this->account_from;
    }

    public function setAccountFrom(int $account_from): TransactionResponse
    {
        $this->account_from = $account_from;

        return $this;
    }

    public function getAccountTo(): int
    {
        return $this->account_to;
    }

    public function setAccountTo(int $account_to): TransactionResponse
    {
        $this->account_to = $account_to;

        return $this;
    }

    public function getClientFrom(): string
    {
        return $this->client_from;
    }

    public function setClientFrom(string $client_from): TransactionResponse
    {
        $this->client_from = $client_from;

        return $this;
    }

    public function getClientTo(): string
    {
        return $this->client_to;
    }

    public function setClientTo(string $client_to): TransactionResponse
    {
        $this->client_to = $client_to;

        return $this;
    }

    public function getCurrencySent(): string
    {
        return $this->currency_sent;
    }

    public function setCurrencySent(string $currency_sent): TransactionResponse
    {
        $this->currency_sent = $currency_sent;

        return $this;
    }

    public function getDate(): string
    {
        return $this->date;
    }

    public function setDate(string $date): TransactionResponse
    {
        $this->date = $date;

        return $this;
    }

    public function getCurrencyReceived(): string
    {
        return $this->currency_received;
    }

    public function setCurrencyReceived(string $currency_received): TransactionResponse
    {
        $this->currency_received = $currency_received;

        return $this;
    }

    public function getTimestamp(): int
    {
        return $this->timestamp;
    }

    public function setTimestamp(int $timestamp): TransactionResponse
    {
        $this->timestamp = $timestamp;

        return $this;
    }
}