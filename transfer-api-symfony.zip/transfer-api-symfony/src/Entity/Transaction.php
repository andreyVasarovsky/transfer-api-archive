<?php

namespace App\Entity;

use App\Repository\TransactionRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: TransactionRepository::class)]
class Transaction
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne(targetEntity: Account::class)]
    #[ORM\JoinColumn(name: 'account_from_id', referencedColumnName: 'id', nullable: false)]
    private Account $account_from;

    #[ORM\ManyToOne(targetEntity: Account::class)]
    #[ORM\JoinColumn(name: 'account_to_id', referencedColumnName: 'id', nullable: false)]
    private Account $account_to;

    #[ORM\Column(type: 'decimal', options: [
        "precision" => 15,
        "scale" => 2
    ])]
    private ?float $amount_from;

    #[ORM\Column(type: 'decimal', options: [
        "precision" => 15,
        "scale" => 2
    ])]
    private ?float $amount_to;

    #[ORM\Column(type: 'decimal', options: [
        "precision" => 15,
        "scale" => 5
    ])]
    private ?float $rates;

    #[ORM\ManyToOne(targetEntity: TransactionStatus::class)]
    #[ORM\JoinColumn(name: 'status_id', referencedColumnName: 'id', nullable: false)]
    private TransactionStatus $status;

    #[ORM\Column(type: 'datetime_immutable')]
    private \DateTimeInterface $updated_at;

    #[ORM\Column(type: 'datetime_immutable')]
    private \DateTimeInterface $created_at;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getAccountFrom(): ?Account
    {
        return $this->account_from;
    }

    public function setAccountFrom(?Account $account_from): Transaction
    {
        $this->account_from = $account_from;

        return $this;
    }

    public function getAccountTo(): Account
    {
        return $this->account_to;
    }

    public function setAccountTo(Account $account_to): Transaction
    {
        $this->account_to = $account_to;

        return $this;
    }

    public function getAmountFrom(): ?float
    {
        return $this->amount_from;
    }

    public function setAmountFrom(?float $amount_from): Transaction
    {
        $this->amount_from = $amount_from;

        return $this;
    }

    public function getAmountTo(): ?float
    {
        return $this->amount_to;
    }

    public function setAmountTo(?float $amount_to): Transaction
    {
        $this->amount_to = $amount_to;

        return $this;
    }

    public function getRates(): ?float
    {
        return $this->rates;
    }

    public function setRates(?float $rates): Transaction
    {
        $this->rates = $rates;

        return $this;
    }

    public function getStatus(): TransactionStatus
    {
        return $this->status;
    }

    public function setStatus(TransactionStatus $status): Transaction
    {
        $this->status = $status;

        return $this;
    }

    public function getUpdatedAt(): \DateTimeInterface
    {
        return $this->updated_at;
    }

    public function setUpdatedAt(\DateTimeInterface $updated_at): Transaction
    {
        $this->updated_at = $updated_at;

        return $this;
    }

    public function getCreatedAt(): \DateTimeInterface
    {
        return $this->created_at;
    }

    public function setCreatedAt(\DateTimeInterface $created_at): Transaction
    {
        $this->created_at = $created_at;

        return $this;
    }
}
