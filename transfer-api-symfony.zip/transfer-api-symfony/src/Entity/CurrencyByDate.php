<?php

namespace App\Entity;

use App\Repository\CurrencyByDateRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: CurrencyByDateRepository::class)]
class CurrencyByDate
{
    #[ORM\Id]
    #[ORM\ManyToOne(targetEntity: Currency::class)]
    #[ORM\JoinColumn(name: 'currency', referencedColumnName: 'code')]
    private ?Currency $currency = null;

    #[ORM\Id]
    #[ORM\Column(type: 'string', nullable: false)]
    private string $date;

    #[ORM\Column(type: 'decimal', options: [
        "precision" => 15,
        "scale" => 5
    ])]
    private ?float $rates;

    public function getRates(): ?float
    {
        return $this->rates;
    }

    public function setRates(?float $rates): CurrencyByDate
    {
        $this->rates = $rates;

        return $this;
    }

    public function getDate(): string
    {
        return $this->date;
    }

    public function setDate(string $date): CurrencyByDate
    {
        $this->date = $date;

        return $this;
    }

    public function getCurrency(): ?Currency
    {
        return $this->currency;
    }

    public function setCurrency(?Currency $currency): CurrencyByDate
    {
        $this->currency = $currency;

        return $this;
    }

}
