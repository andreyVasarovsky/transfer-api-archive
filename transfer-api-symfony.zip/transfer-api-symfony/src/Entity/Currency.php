<?php

namespace App\Entity;

use App\Repository\CurrencyRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: CurrencyRepository::class)]
class Currency
{
    #[ORM\Id]
    #[ORM\Column(length: 3)]
    private ?string $code = null;

    #[ORM\Column(type: 'decimal', options: [
        "precision" => 15,
        "scale" => 5
    ])]
    private ?float $rates;

    #[ORM\Column(type: 'datetime_immutable')]
    private \DateTimeInterface $updated_at;

    #[ORM\Column(type: 'datetime_immutable')]
    private \DateTimeInterface $created_at;


    public function getCode(): ?string
    {
        return $this->code;
    }

    public function setCode(?string $code): Currency
    {
        $this->code = $code;

        return $this;
    }

    public function getRates(): ?float
    {
        return $this->rates;
    }

    public function setRates(?float $rates): Currency
    {
        $this->rates = $rates;

        return $this;
    }

    public function getUpdatedAt(): \DateTimeInterface
    {
        return $this->updated_at;
    }

    public function setUpdatedAt(\DateTimeInterface $updated_at): Currency
    {
        $this->updated_at = $updated_at;

        return $this;
    }

    public function getCreatedAt(): \DateTimeInterface
    {
        return $this->created_at;
    }

    public function setCreatedAt(\DateTimeInterface $created_at): Currency
    {
        $this->created_at = $created_at;

        return $this;
    }
}
