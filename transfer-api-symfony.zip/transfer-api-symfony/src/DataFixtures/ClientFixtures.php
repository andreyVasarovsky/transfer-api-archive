<?php

namespace App\DataFixtures;

use App\Entity\Client;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Common\DataFixtures\DependentFixtureInterface;
use Doctrine\Persistence\ObjectManager;

class ClientFixtures extends Fixture
{
    const QTY_OF_CLIENTS = 5;

    const NAMES = ['Andrejs', 'Viktorija', 'Aleksandrs', 'John', 'Kristaps'];
    const LASTNAMES = ['Vasarovskis', 'Aboltiņa', 'Možķis', 'Doe', 'Pronsis'];

    public function load(ObjectManager $manager): void
    {
        for ($i = 0; $i < self::QTY_OF_CLIENTS; $i++) {
            $client = new Client();
            $client
                ->setFirstname(self::NAMES[$i])
                ->setLastname(self::LASTNAMES[$i])
                ->setEmail(mb_strtolower(self::NAMES[$i]) . '.' . mb_strtolower(self::LASTNAMES[$i]) . '@gmail.com')
                ->setCreatedAt((new \DateTimeImmutable()));
            $manager->persist($client);
            $manager->flush();

            $this->addReference("Client-$i", $client);
        }
    }
}
