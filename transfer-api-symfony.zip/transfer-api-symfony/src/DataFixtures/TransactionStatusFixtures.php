<?php

namespace App\DataFixtures;

use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;
use App\Entity\TransactionStatus;

class TransactionStatusFixtures extends Fixture
{
    const NEW_STATUS_REFERENCE = 'New';
    const PENDING_STATUS_REFERENCE = 'Pending';
    const COMPLETED_STATUS_REFERENCE = 'Completed';
    const CANCELED_STATUS_REFERENCE = 'Canceled';

    const STATUS_REFERENCE_LIST = [
        self::NEW_STATUS_REFERENCE,
        self::PENDING_STATUS_REFERENCE,
        self::COMPLETED_STATUS_REFERENCE,
        self::CANCELED_STATUS_REFERENCE,
    ];

    public function load(ObjectManager $manager): void
    {
        foreach (self::STATUS_REFERENCE_LIST as $status) {
            $statusEntity = $this->createTransactionStatus($manager, $status);
            $this->addReference($status, $statusEntity);
        }
    }

    private function createTransactionStatus(ObjectManager $manager, string $status): TransactionStatus
    {
        $statusEntity = (new TransactionStatus())->setTitle($status);
        $manager->persist($statusEntity);
        $manager->flush();

        return $statusEntity;
    }
}
