<?php

namespace App\DataFixtures;

use App\Entity\Currency;
use App\Entity\CurrencyByDate;
use App\Repository\CurrencyRepository;
use App\Service\CurrencyByDateService;
use App\Service\CurrencyService;
use App\Utility\API\ExchangeRate\ExchangeRateAPI;
use App\Utility\API\Rates;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;
use Symfony\Component\Console\Output\ConsoleOutput;

class CurrencyFixtures extends Fixture
{
    const EUR_REFERENCE = 'EUR';
    const USD_REFERENCE = 'USD';

    public function __construct(
        private readonly CurrencyService       $currencyService,
        private readonly CurrencyRepository    $currencyRepository,
        private readonly CurrencyByDateService $currencyByDateService,
        private readonly ExchangeRateAPI       $api)
    {
    }

    public function load(ObjectManager $manager): void
    {
        $output = new ConsoleOutput();

        try {
            (new Rates($this->api, $this->currencyService, $this->currencyByDateService))->updateToday();
        } catch (\Exception $exception) {
            $error = '   > <error>Currency Fixtures failed because of "' . $exception->getMessage();
            $error .= '" you can try to rerun fixtures:load after few minutes.</error>';
            $output->writeln($error);

            $EUR = (new Currency())
                ->setCode(self::EUR_REFERENCE)
                ->setRates(1)
                ->setCreatedAt(new \DateTimeImmutable())
                ->setUpdatedAt(new \DateTimeImmutable());

            $USD = (new Currency())
                ->setCode(self::USD_REFERENCE)
                ->setRates(1.07)
                ->setCreatedAt(new \DateTimeImmutable())
                ->setUpdatedAt(new \DateTimeImmutable());

            $manager->persist($EUR);
            $manager->persist($USD);
            $manager->flush();

            $manager->persist((new CurrencyByDate())
                ->setDate((new \DateTime())->format('Y-m-d'))
                ->setRates(1)
                ->setCurrency($EUR));
            $manager->persist((new CurrencyByDate())
                ->setDate((new \DateTime())->format('Y-m-d'))
                ->setRates(1.07)
                ->setCurrency($USD));

            $manager->flush();

            $created = '   > <info>Random Currency rates created</info>';
            $output->writeln($created);
        }

        $this->addReference(self::EUR_REFERENCE, $this->currencyRepository->getByCode(self::EUR_REFERENCE));
        $this->addReference(self::USD_REFERENCE, $this->currencyRepository->getByCode(self::USD_REFERENCE));
    }
}
