<?php

namespace App\DataFixtures;

use App\Entity\Account;
use App\Repository\CurrencyRepository;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Common\DataFixtures\DependentFixtureInterface;
use Doctrine\Persistence\ObjectManager;

class AccountFixtures extends Fixture implements DependentFixtureInterface
{
    public function __construct(private readonly CurrencyRepository $currencyRepository)
    {
    }

    public function load(ObjectManager $manager): void
    {
        $currencyList = $this->currencyRepository->findAll();
        if (empty($currencyList))
            $currencyList = [
                $this->getReference(CurrencyFixtures::EUR_REFERENCE),
                $this->getReference(CurrencyFixtures::USD_REFERENCE),
            ];

        for ($i = 0; $i < ClientFixtures::QTY_OF_CLIENTS; $i++) {
            foreach ($currencyList as $currency) {
                $account = (new Account())
                    ->setClient($this->getReference("Client-$i"))
                    ->setCurrency($currency)
                    ->setBalance(mt_rand(100, 500) + abs(1 - mt_rand() / mt_rand()))
                    ->setUpdatedAt(new \DateTimeImmutable())
                    ->setCreatedAt(new \DateTimeImmutable());

                $manager->persist($account);
                $manager->flush();

                $code = $currency->getCode();

                $this->addReference("Account-$i-$code", $account);
            }
        }
    }

    public function getDependencies(): array
    {
        return [
            ClientFixtures::class,
            CurrencyFixtures::class,
        ];
    }
}
