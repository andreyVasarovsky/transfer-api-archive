<?php

namespace App\DataFixtures;

use App\Entity\Transaction;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Common\DataFixtures\DependentFixtureInterface;
use Doctrine\Persistence\ObjectManager;

class TransactionFixtures extends Fixture implements DependentFixtureInterface
{
    const QTY_OF_TRANSACTION = 25;

    public function load(ObjectManager $manager): void
    {

        $clientQty = ClientFixtures::QTY_OF_CLIENTS;
        for ($i = 0; $i < $clientQty; $i++) {
            foreach ([CurrencyFixtures::EUR_REFERENCE, CurrencyFixtures::USD_REFERENCE] as $currency) {
                $accountTo = $this->getRandomToIndex($i);
                $accountTo = $this->getReference("Account-$accountTo-$currency");
                $accountFrom = $this->getReference("Account-$i-$currency");

                for ($j = 0; $j < self::QTY_OF_TRANSACTION; $j++) {
                    $amount = mt_rand('0.01', $accountTo->getBalance()) + abs(1 - mt_rand() / mt_rand());
                    $date = '2023-' . rand(1, 12) . '-' . rand(1, 27);
                    $transaction = new Transaction();
                    $transaction
                        ->setAccountFrom($accountFrom)
                        ->setAccountTo($accountTo)
                        ->setAmountFrom($amount)
                        ->setAmountTo($amount)
                        ->setRates(1)
                        ->setStatus($this->getRandomStatus())
                        ->setUpdatedAt(new \DateTimeImmutable($date))
                        ->setCreatedAt(new \DateTimeImmutable($date));
                    $manager->persist($transaction);
                    $manager->flush();
                }
            }
        }
    }

    private function getRandomToIndex(int $index): int
    {
        $toIndex = $index;
        while ($toIndex == $index) {
            $toIndex = (rand(1, ClientFixtures::QTY_OF_CLIENTS) - 1);
        }

        return $toIndex;
    }

    private function getRandomStatus()
    {
        $index = (rand(1, count(TransactionStatusFixtures::STATUS_REFERENCE_LIST))) - 1;
        return $this->getReference(TransactionStatusFixtures::STATUS_REFERENCE_LIST[$index]);
    }

    public function getDependencies(): array
    {
        return [
            AccountFixtures::class,
            CurrencyFixtures::class,
            TransactionStatusFixtures::class,
        ];
    }
}
