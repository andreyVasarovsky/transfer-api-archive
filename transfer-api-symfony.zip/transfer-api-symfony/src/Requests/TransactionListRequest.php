<?php

namespace App\Requests;

use Symfony\Component\Validator\Constraints\Type;

class TransactionListRequest extends BaseRequest
{
    #[Type('numeric')]
    protected int|string $offset;

    #[Type('numeric')]
    protected int|string $limit;
}