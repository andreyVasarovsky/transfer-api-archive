<?php

namespace App\Controller;

use App\Model\ErrorResponse;
use App\Model\TransactionListResponse;
use App\Requests\TransactionListRequest;
use App\Service\AccountService;
use Nelmio\ApiDocBundle\Annotation\Security;
use OpenApi\Attributes as OA;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Nelmio\ApiDocBundle\Annotation\Model;

class AccountController extends AbstractController
{
    public function __construct(private readonly AccountService $accountService)
    {
    }

    #[OA\Tag(name: 'Transactions')]
    #[OA\Response(
        response: 200,
        description: 'Returns the transactions of an account',
        attachables: [new Model(type: TransactionListResponse::class)],
    )]
    #[OA\Response(
        response: 404,
        description: 'Account not found',
        attachables: [new Model(type: ErrorResponse::class)],
    )]
    #[OA\Parameter(
        name: 'offset', description: 'Offset records', in: 'query', schema: new OA\Schema(type: 'numeric')
    )]
    #[OA\Parameter(
        name: 'limit', description: 'Limit records qty', in: 'query', schema: new OA\Schema(type: 'numeric')
    )]
    #[Route(path: '/api/v1/account/{id}/transactions', methods: ['GET'])]
    #[Security(name: 'Bearer')]
    public function transactionsByAccountId(TransactionListRequest $request, $id): Response
    {
        if (!is_numeric($id))
            return $this->json(new ErrorResponse('invalid_parameter_id', [], false,),  status: 500);
        try {
            return $this->json($this->accountService->getTransactionsById(intval($id), $request->validated()));
        } catch (\Exception $e) {
            return $this->json(new ErrorResponse($e->getMessage(), [], false), status: 404);
        }
    }
}