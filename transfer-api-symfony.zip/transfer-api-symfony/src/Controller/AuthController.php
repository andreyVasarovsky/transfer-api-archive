<?php

namespace App\Controller;

class AuthController
{

}