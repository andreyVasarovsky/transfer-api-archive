<?php

namespace App\Controller;

use App\Attribule\RequestBody;
use App\Model\DefaultListResponse;
use App\Model\ErrorResponse;
use App\Model\IdResponse;
use App\Model\TransferFundsRequest;
use App\Service\AccountService;
use Nelmio\ApiDocBundle\Annotation\Model;
use Nelmio\ApiDocBundle\Annotation\Security;
use OpenApi\Attributes as OA;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class TransferController extends AbstractController
{
    public function __construct(private readonly AccountService $accountService)
    {
    }

    #[Route(path: '/api/v1/transfer', methods: ['POST'])]
    #[OA\Tag(name: 'Transfer')]
    #[OA\RequestBody(attachables: [new Model(type: TransferFundsRequest::class)])]
    #[OA\Response(response: 200, description: 'Created', attachables: [new Model(type: IdResponse::class)])]
    #[OA\Response(response: 400, description: 'Creation error',
        attachables: [new Model(type: ErrorResponse::class)]
    )]
    #[Security(name: 'Bearer')]
    public function transferFunds(#[RequestBody] TransferFundsRequest $request): Response
    {
        try {
            return $this->json($this->accountService->transfer($request));
        } catch (\Exception $e) {
            return $this->json(new ErrorResponse($e->getMessage(), [], false));
        }
    }
}