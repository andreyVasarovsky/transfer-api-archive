<?php

namespace App\Controller;

use App\Repository\AccountRepository;
use App\Repository\ClientRepository;
use App\Repository\CurrencyRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class HomeController extends AbstractController
{
    public function __construct(
        private readonly ClientRepository $clientRepository,
        private readonly AccountRepository $accountRepository
    )
    {
    }

    #[Route('/')]
    public function number(): Response
    {
        try {
            $clients = $this->clientRepository->findAll();
            $accounts = $this->accountRepository->findAll();
        } catch (\Exception $exception) {
            dd($exception->getMessage());
        }

        return $this->render('home.html.twig', [
            'clients' => $clients,
            'accounts' => $accounts,
        ]);
    }
}