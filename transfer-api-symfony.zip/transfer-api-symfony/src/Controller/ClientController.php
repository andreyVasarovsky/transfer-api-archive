<?php

namespace App\Controller;

use App\Model\AccountListResponse;
use App\Model\DefaultListResponse;
use App\Model\ErrorResponse;
use App\Service\ClientService;
use Nelmio\ApiDocBundle\Annotation\Model;
use Nelmio\ApiDocBundle\Annotation\Security;
use OpenApi\Attributes as OA;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class ClientController extends AbstractController
{
    public function __construct(private readonly ClientService $clientService)
    {
    }

    #[OA\Tag(name: 'Accounts')]
    #[OA\Response(
        response: 200,
        description: 'Returns the accounts of an client',
        attachables: [new Model(type: AccountListResponse::class)],
    )]
    #[OA\Response(
        response: 404,
        description: 'Client not found',
        attachables: [new Model(type: ErrorResponse::class)],
    )]
    #[Security(name: 'Bearer')]
    #[Route(path: '/api/v1/client/{id}/accounts', methods: ['GET'])]
    public function accountsByClientId(int $id): Response
    {
        try {
            return $this->json($this->clientService->getAccountsById($id));
        } catch (\Exception $e) {
            return $this->json(new ErrorResponse($e->getMessage(), [], false), status: 404);
        }
    }
}