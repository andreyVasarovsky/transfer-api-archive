<?php

namespace App\Exception;

class TransferInvalidRecipientAccountCurrencyNotMatchException extends \RuntimeException
{
    public function __construct()
    {
        parent::__construct('recipient_currency_is_not_same_with_transfer');
    }
}