<?php

namespace App\Exception;

class TransferRecipientAccountIsNotExistsException extends \RuntimeException
{
    public function __construct()
    {
        parent::__construct('recipient_account_id_is_not_exists');
    }
}
