<?php

namespace App\Exception;

class InvalidOperationException extends \RuntimeException
{
    public function __construct()
    {
        parent::__construct('invalid_operation');
    }
}
