<?php

namespace App\Exception;

class NotEnoughBalanceException extends \RuntimeException
{
    public function __construct()
    {
        parent::__construct('not_enough_balance');
    }
}