<?php

namespace App\Exception;

class InvalidCurrencyCreateOrUpdateDataException extends \RuntimeException
{
    public function __construct()
    {
        parent::__construct('currency_update/create_request_data_is_incorrect');
    }
}