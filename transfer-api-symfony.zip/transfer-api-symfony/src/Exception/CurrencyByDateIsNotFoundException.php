<?php

namespace App\Exception;

class CurrencyByDateIsNotFoundException extends \RuntimeException
{
    public function __construct()
    {
        parent::__construct('currency_for_specific_date_is_not_found');
    }
}