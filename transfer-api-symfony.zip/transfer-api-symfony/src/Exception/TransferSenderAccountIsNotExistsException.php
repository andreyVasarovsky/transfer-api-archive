<?php

namespace App\Exception;

class TransferSenderAccountIsNotExistsException extends \RuntimeException
{
    public function __construct()
    {
        parent::__construct('sender_account_id_is_not_exists');
    }
}
