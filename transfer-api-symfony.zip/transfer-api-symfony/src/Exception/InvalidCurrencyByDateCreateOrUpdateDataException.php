<?php

namespace App\Exception;

class InvalidCurrencyByDateCreateOrUpdateDataException extends \RuntimeException
{
    public function __construct()
    {
        parent::__construct('currency_by_date_update_or_create_request_data_is_incorrect');
    }
}