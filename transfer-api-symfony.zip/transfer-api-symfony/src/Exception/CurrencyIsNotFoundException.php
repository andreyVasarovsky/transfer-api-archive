<?php

namespace App\Exception;

class CurrencyIsNotFoundException extends \RuntimeException
{
    public function __construct()
    {
        parent::__construct('currency_is_not_found');
    }
}