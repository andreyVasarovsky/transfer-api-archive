<?php

namespace App\Exception;

class RatesLoadingFailedException extends \RuntimeException
{
    public function __construct()
    {
        parent::__construct('currency_rates_currently_are_not_available');
    }
}