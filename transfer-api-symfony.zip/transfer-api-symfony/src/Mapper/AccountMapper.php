<?php

namespace App\Mapper;

use App\Model\AccountResponse;

class AccountMapper
{
    public static function map(array $accountList): array
    {
        $response = [];
        if (!empty($accountList)) {
            foreach ($accountList as $account) {
                $response[] = (new AccountResponse())
                    ->setId($account->getId())
                    ->setBalance(floatval(number_format($account->getBalance(), 2, '.')))
                    ->setCurrency($account->getCurrency()->getCode());
            }
        }

        return $response;
    }
}