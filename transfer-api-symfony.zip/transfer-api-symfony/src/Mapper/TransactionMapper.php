<?php

namespace App\Mapper;

use App\Model\TransactionResponse;

class TransactionMapper
{
    const RECEIVE = 'receive';
    const SENDING = 'sending';
    public static function map(?int $accountId, array $transactionList): array
    {
        $response = [];
        if (!empty($transactionList)) {
            foreach ($transactionList as $transaction) {
                $type = $transaction->getAccountTo()->getId() == $accountId ? self::RECEIVE : self::SENDING;
                $amount = $type == self::SENDING ? ($transaction->getAmountFrom() * -1) : $transaction->getAmountTo();
                $response[] = (new TransactionResponse())
                    ->setId($transaction->getId())
                    ->setType($type)
                    ->setStatus($transaction->getStatus()->getTitle())
                    ->setAmount(floatval(number_format($amount, 2, '.')))
                    ->setAccountFrom($transaction->getAccountFrom()->getId())
                    ->setAccountTo($transaction->getAccountTo()->getId())
                    ->setClientFrom($transaction->getAccountFrom()->getClient()->getFullName())
                    ->setClientTo($transaction->getAccountTo()->getClient()->getFullName())
                    ->setCurrencySent($transaction->getAccountFrom()->getCurrency()->getCode())
                    ->setCurrencyReceived($transaction->getAccountTo()->getCurrency()->getCode())
                    ->setDate($transaction->getCreatedAt()->format('Y-m-d H:i:s'))
                    ->setTimestamp($transaction->getCreatedAt()->getTimestamp());
            }
        }

        return $response;
    }
}