<?php

namespace App\Utility\API;

use App\Exception\RatesLoadingFailedException;
use App\Model\CurrencyByDateUpdateOrCreateRequest;
use App\Model\CurrencyUpdateOrCreateRequest;
use App\Service\CurrencyByDateService;
use App\Service\CurrencyService;
use App\Utility\API\ExchangeRate\API;

class Rates
{
    public function __construct(
        private readonly API                   $api,
        private readonly CurrencyService       $currencyService,
        private readonly CurrencyByDateService $currencyByDateService)
    {
    }

    public function updateToday(): void
    {
        $response = $this->api->getLatest();
        if (!$response->getStatus() || !$response->dataFieldExists('rates'))
            throw new RatesLoadingFailedException();

        $rates = $response->getDataByKey('rates');
        $this->currencyService->resetRatesExcludeCodes(array_keys($rates));

        foreach ($rates as $code => $rate) {
            //Currency
            $request = (new CurrencyUpdateOrCreateRequest())
                ->setCode($code)
                ->setRates($rate);
            $currency = $this->currencyService->updateOrCreate($request);

            //Currency By Date
            $request = (new CurrencyByDateUpdateOrCreateRequest())
                ->setCode($code)
                ->setRates($rate)
                ->setDate((new \DateTime())->format('Y-m-d'));
            $this->currencyByDateService->updateOrCreate($request, $currency);
        }
    }
}