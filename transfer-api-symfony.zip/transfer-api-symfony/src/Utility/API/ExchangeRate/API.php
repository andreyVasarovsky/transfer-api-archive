<?php

namespace App\Utility\API\ExchangeRate;

use Exception;
use GuzzleHttp\Exception\GuzzleException;

class API
{
    protected function request(string $url = '', array $data = [], array $headers = [], string $method = 'POST'): array
    {
        $client = new \GuzzleHttp\Client();

        if ($method === 'POST') {
            try {
                $response = $client->post($url, [
                    'headers' => $headers,
                    'body' => json_encode($data),
                ]);
                $response = json_decode($response->getBody()->getContents(), true);
            } catch (GuzzleException | Exception $e) {
                $data = method_exists($e, 'getResponse') ?
                    json_decode($e->getResponse()->getBody()->getContents(), true) :
                    ['message' => 'failed_to_fetch_api_data'];
                $response = [
                    'success' => false,
                    'message' => $data->message
                ];
            }
        } else if ($method === 'GET') {
            try {
                $url = empty($data) ? $url : $url . '?' . http_build_query($data);
                $response = $client->get($url, [
                    'headers' => $headers,
                ]);
                $response = json_decode($response->getBody()->getContents(), true);
            } catch (GuzzleException | Exception $e) {
                $data = method_exists($e, 'getResponse') ?
                    json_decode($e->getResponse()->getBody()->getContents(), true) :
                    ['message' => 'failed_to_fetch_api_data'];
                $response = [
                    'success' => false,
                    'message' => $data->message ?? 'Request failed'
                ];
            }
        } else {
            $response = [
                'success' => false,
                'message' => 'Unknown request method'
            ];
        }

        return $response;
    }
}