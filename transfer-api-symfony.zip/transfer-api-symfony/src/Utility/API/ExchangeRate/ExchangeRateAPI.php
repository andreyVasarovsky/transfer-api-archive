<?php

namespace App\Utility\API\ExchangeRate;

use App\Utility\API\ExchangeRate\Traits\EndpointsTrait;
use App\Utility\API\RatesAPIInterface;
use App\Utility\API\Response;

class ExchangeRateAPI extends API implements RatesAPIInterface
{
    use EndpointsTrait;

    public function getLatest(): Response
    {
        $headers = [
            'apikey' => self::$token,
            'Content-Type' => 'application/json',
            'Accept' => 'application/json'
        ];
        $endpoint = $this->getEndpoint('latest');

        $response = $this->request($endpoint, [], $headers, 'GET');

        if (!$response['success'])
            return new Response($response['message']);

        return new Response($response['message'] ?? '', $response, $response['success']);
    }
}