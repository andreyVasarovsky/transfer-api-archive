<?php

namespace App\Utility\API\ExchangeRate\Traits;

use Doctrine\ORM\Mapping as ORM;

trait EndpointsTrait
{
    #[ORM\Column(type: 'string')]
    private static string $token = 'rBFGerkaEBqdEbCwrKhPn5X1oiCy93p0';
    private static array $endpoints = [
        'latest' => 'https://api.apilayer.com/exchangerates_data/latest',
    ];

    public static function getEndpoint(string $title, array $replace = []): string
    {
        $endpoint = '';
        if (isset(self::$endpoints[$title]) && !empty(self::$endpoints[$title])) {
            $endpoint = self::$endpoints[$title];
            if (!empty($replace)) {
                foreach ($replace as $key => $value) {
                    $endpoint = str_replace($key, $value, $endpoint);
                }
            }
        }

        return $endpoint;
    }
}