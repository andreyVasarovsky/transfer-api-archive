<?php

namespace App\Utility\API;

interface RatesAPIInterface
{
    public function getLatest(): Response;
}