<?php

namespace App\Utility\API;

class Response implements RatesAPIResponseInterface
{
    private bool $status;
    private string $message;
    private array $data;

    public function __construct(string $message, array $data = [], bool $status = false)
    {
        $this->setMessage($message)->setData($data)->setStatus($status);
    }

    public function getStatus(): bool
    {
        return $this->status;
    }

    public function setStatus(bool $status): RatesAPIResponseInterface
    {
        $this->status = $status;

        return $this;
    }

    public function getMessage(): string
    {
        return $this->message;
    }

    public function setMessage(string $message): RatesAPIResponseInterface
    {
        $this->message = $message;

        return $this;
    }

    public function getData(): array
    {
        return $this->data;
    }

    public function setData(array $data): RatesAPIResponseInterface
    {
        $this->data = $data;

        return $this;
    }

    public function dataFieldExists(string $key): bool
    {
        return !empty($this->data) && array_key_exists($key, $this->data);
    }

    public function getDataByKey(string $key)
    {
        return $this->dataFieldExists($key) ? $this->data[$key] : [];
    }
}