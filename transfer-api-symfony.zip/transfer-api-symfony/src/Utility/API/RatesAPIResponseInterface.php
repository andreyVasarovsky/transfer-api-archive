<?php

namespace App\Utility\API;

interface RatesAPIResponseInterface
{
    public function __construct(string $message, array $data = [], bool $status = false);

    public function getStatus(): bool;

    public function setStatus(bool $status): self;

    public function getMessage(): string;

    public function setMessage(string $message): self;

    public function getData(): array;

    public function setData(array $data): self;

    public function dataFieldExists(string $key): bool;

    public function getDataByKey(string $key);
}