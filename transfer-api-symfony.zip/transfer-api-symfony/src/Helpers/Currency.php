<?php

namespace App\Helpers;

use App\Exception\CurrencyByDateIsNotFoundException;
use App\Repository\CurrencyByDateRepository;

class Currency
{
    const DEFAULT_CURRENCY = 'EUR';
    const DEFAULT_CURRENCY_RATE = 1;

    private static array $ratesByDateList = [];

    public function __construct(private readonly CurrencyByDateRepository $currencyByDateRepository)
    {
    }

    public function getAmount(float $amount, string $fromCurrency, string $toCurrency, \DateTime $date): float
    {
        if ($fromCurrency === $toCurrency)
            return $amount;

        $toCurrencyRate = $this->getRatesByDate($toCurrency, $date);
        $eurAmount = $this->getAmountEUR($amount, $fromCurrency, $date);

        if (is_null($toCurrencyRate) || empty($eurAmount))
            return 0.00;

        return round(floatval($eurAmount * $toCurrencyRate), 2);
    }

    public function getRatesByDate(string $currency, \DateTime $date)
    {
        if ($currency === self::DEFAULT_CURRENCY)
            return self::DEFAULT_CURRENCY_RATE;

        if (!isset(self::$ratesByDateList[$currency][$date->format('Y-m-d')])) {
            if ($this->currencyByDateRepository->existsByCodeDate($currency, $date->format('Y-m-d'))) {
                $entity = $this->currencyByDateRepository->getByCodeDate($currency, $date->format('Y-m-d'));
                self::$ratesByDateList[$currency][$date->format('Y-m-d')] = $entity->getRates();
            } else {
                throw new CurrencyByDateIsNotFoundException();
            }
        }

        return self::$ratesByDateList[$currency][$date->format('Y-m-d')];
    }

    public function getAmountEUR($amount, $fromCurrency, \DateTime $date): float
    {
        $rate = $this->getRatesByDate($fromCurrency, $date);
        if (is_null($rate))
            return 0.00;
        return round(floatval($amount * round((1 / $rate), 4)), 2);
    }
}