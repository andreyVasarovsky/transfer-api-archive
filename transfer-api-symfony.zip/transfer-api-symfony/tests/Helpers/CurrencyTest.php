<?php

namespace App\Tests\Helpers;

use App\Exception\CurrencyByDateIsNotFoundException;
use App\Helpers\Currency;
use App\Entity\CurrencyByDate;
use App\Entity\Currency as CurrencyEntity;
use App\Repository\CurrencyByDateRepository;
use PHPUnit\Framework\TestCase;
use ReflectionProperty;


class CurrencyTest extends TestCase
{
    const ONE_USD_IN_EUR = '0.93';
    const USD_CURRENCY = 'USD';
    const EUR_CURRENCY = 'EUR';
    const USD_RATES = '1.07687';
    const DEFAULT_DATE = '2024-01-01';

    public function testGetAmount_Success()
    {
        $currencyByDateRepository = $this->createMock(CurrencyByDateRepository::class);
        $currencyByDateRepository
            ->expects($this->once())
            ->method('existsByCodeDate')
            ->with(self::USD_CURRENCY, self::DEFAULT_DATE)
            ->willReturn(true);
        $currencyByDateRepository
            ->expects($this->once())
            ->method('getByCodeDate')
            ->with(self::USD_CURRENCY, self::DEFAULT_DATE)
            ->willReturn($this->getCurrencyByDateEntity(self::USD_CURRENCY, self::USD_RATES));

        $resulted = (new Currency($currencyByDateRepository))
            ->GetAmount(1, self::USD_CURRENCY, self::EUR_CURRENCY, $this->getDefaultDateTime());

        $this->assertEquals(self::ONE_USD_IN_EUR, $resulted);
        unset($currencyByDateRepository);
    }

    public function testGetAmount_SameCurrency()
    {
        $currencyByDateRepository = $this->createMock(CurrencyByDateRepository::class);
        $expected = 1;

        $resulted = (new Currency($currencyByDateRepository))->GetAmount($expected, self::USD_CURRENCY, self::USD_CURRENCY, $this->getDefaultDateTime());

        $this->assertEquals($expected, $resulted);

    }

    public function testGetAmountEUR_Success()
    {
        $currencyByDateRepository = $this->createMock(CurrencyByDateRepository::class);
        $currencyByDateRepository
            ->expects($this->once())
            ->method('existsByCodeDate')
            ->with(self::USD_CURRENCY, self::DEFAULT_DATE)
            ->willReturn(true);
        $currencyByDateRepository
            ->expects($this->once())
            ->method('getByCodeDate')
            ->with(self::USD_CURRENCY, self::DEFAULT_DATE)
            ->willReturn($this->getCurrencyByDateEntity(self::USD_CURRENCY, self::USD_RATES));

        $currency = (new Currency($currencyByDateRepository));

        try {
            $property = new ReflectionProperty($currency, 'ratesByDateList');
            $property->setValue([]);
        } catch (\ReflectionException $e) {
            $this->fail("Test can't reset static property");
        }

        $EUR = $currency->getAmountEUR(1, self::USD_CURRENCY, $this->getDefaultDateTime());

        $this->assertEquals(self::ONE_USD_IN_EUR, $EUR);
    }

    public function testGetRatesByDate_DefaultCurrency()
    {
        $currencyByDateRepository = $this->createMock(CurrencyByDateRepository::class);

        $rates = (new Currency($currencyByDateRepository))
            ->getRatesByDate(Currency::DEFAULT_CURRENCY, $this->getDefaultDateTime());

        $this->assertEquals(Currency::DEFAULT_CURRENCY_RATE, $rates);
    }

    public function testGetRatesByDate_CurrencyByDateNotExistsException()
    {
        $currencyByDateRepository = $this->createMock(CurrencyByDateRepository::class);
        $currencyByDateRepository
            ->expects($this->once())
            ->method('existsByCodeDate')
            ->with(self::USD_CURRENCY, self::DEFAULT_DATE)
            ->willReturn(false);

        $this->expectException(CurrencyByDateIsNotFoundException::class);

        $currency = (new Currency($currencyByDateRepository));

        try {
            $property = new ReflectionProperty($currency, 'ratesByDateList');
            $property->setValue([]);
        } catch (\ReflectionException $e) {
            $this->fail("Test can't reset static property");
        }

        $currency->getRatesByDate(self::USD_CURRENCY, $this->getDefaultDateTime());
    }

    public function testGetRatesByDate_Success()
    {
        $currencyByDateRepository = $this->createMock(CurrencyByDateRepository::class);
        $currencyByDateRepository
            ->expects($this->once())
            ->method('existsByCodeDate')
            ->with(self::USD_CURRENCY, self::DEFAULT_DATE)
            ->willReturn(true);
        $currencyByDateRepository
            ->expects($this->once())
            ->method('getByCodeDate')
            ->with(self::USD_CURRENCY, self::DEFAULT_DATE)
            ->willReturn($this->getCurrencyByDateEntity(self::USD_CURRENCY, self::USD_RATES));

        $currency = (new Currency($currencyByDateRepository));

        try {
            $property = new ReflectionProperty($currency, 'ratesByDateList');
            $property->setValue([]);
        } catch (\ReflectionException $e) {
            $this->fail("Test can't reset static property");
        }

        $rates = $currency->getRatesByDate(self::USD_CURRENCY, $this->getDefaultDateTime());

        $this->assertEquals(self::USD_RATES, $rates);
    }

    private function getCurrencyEntity(string $code, float $rates): CurrencyEntity
    {
        return (new CurrencyEntity())
            ->setCode($code)
            ->setRates($rates);
    }

    private function getCurrencyByDateEntity(string $code, float $rates): CurrencyByDate
    {
        return (new CurrencyByDate())
            ->setCurrency($this->getCurrencyEntity($code, $rates))
            ->setRates($rates);
    }

    private function getDefaultDateTime(): \DateTime
    {
        return new \DateTime(self::DEFAULT_DATE);
    }
}
