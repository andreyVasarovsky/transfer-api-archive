<?php

namespace App\Tests\Utility\API;

use App\Entity\Currency;
use App\Entity\CurrencyByDate;
use App\Exception\RatesLoadingFailedException;
use App\Model\CurrencyByDateUpdateOrCreateRequest;
use App\Model\CurrencyUpdateOrCreateRequest;
use App\Service\CurrencyByDateService;
use App\Service\CurrencyService;
use App\Utility\API\ExchangeRate\ExchangeRateAPI;
use App\Utility\API\Rates;
use App\Utility\API\Response;
use PHPUnit\Framework\TestCase;

class RatesTest extends TestCase
{
    const EUR_CURRENCY = 'EUR';

    public function testUpdateToday_Exception()
    {
        $api = $this->createMock(ExchangeRateAPI::class);
        $currencyService = $this->createMock(CurrencyService::class);
        $currencyByDateService = $this->createMock(CurrencyByDateService::class);

        $api->expects($this->once())->method('getLatest')->willReturn(new Response('Test fail'));

        $this->expectException(RatesLoadingFailedException::class);

        (new Rates($api, $currencyService, $currencyByDateService))->updateToday();
    }

    public function testUpdateToday_Success()
    {
        $api = $this->createMock(ExchangeRateAPI::class);
        $currencyService = $this->createMock(CurrencyService::class);
        $currencyByDateService = $this->createMock(CurrencyByDateService::class);

        $api
            ->expects($this->once())
            ->method('getLatest')
            ->willReturn(new Response('Success', [
                'rates' => [
                    self::EUR_CURRENCY => 1,
                ],
            ], true));
        $currencyService
            ->expects($this->once())
            ->method('updateOrCreate')
            ->with((new CurrencyUpdateOrCreateRequest())->setCode(self::EUR_CURRENCY)->setRates(1))
            ->willReturn($this->getCurrencyEUR());

        $currencyByDateService
            ->expects($this->once())
            ->method('updateOrCreate')
            ->with(
                (new CurrencyByDateUpdateOrCreateRequest())
                    ->setCode(self::EUR_CURRENCY)
                    ->setRates(1)
                    ->setDate((new \DateTime())->format('Y-m-d'))
            )
            ->willReturn($this->getCurrencyByDateEUR());

        (new Rates($api, $currencyService, $currencyByDateService))->updateToday();
    }

    private function getCurrencyEUR(): Currency
    {
        return (new Currency())
            ->setCode(self::EUR_CURRENCY)
            ->setRates(1)
            ->setCreatedAt(new \DateTimeImmutable('2024-01-01 12:00:00'))
            ->setUpdatedAt(new \DateTimeImmutable('2024-01-01 12:00:00'));
    }

    private function getCurrencyByDateEUR(): CurrencyByDate
    {
        return (new CurrencyByDate())
            ->setCurrency($this->getCurrencyEUR())
            ->setRates(1)
            ->setDate((new \DateTime())->format('Y-m-d'));
    }
}
