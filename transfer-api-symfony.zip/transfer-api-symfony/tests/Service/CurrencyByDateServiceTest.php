<?php

namespace App\Tests\Service;

use App\Entity\Currency;
use App\Entity\CurrencyByDate;
use App\Exception\InvalidCurrencyByDateCreateOrUpdateDataException;
use App\Model\CurrencyByDateUpdateOrCreateRequest;
use App\Repository\CurrencyByDateRepository;
use App\Repository\CurrencyRepository;
use App\Service\CurrencyByDateService;
use PHPUnit\Framework\TestCase;

class CurrencyByDateServiceTest extends TestCase
{
    const EUR_CURRENCY = 'EUR';

    public function testGetCurrencyByDate_Exists()
    {
        $expected = (new CurrencyByDate())
            ->setCurrency($this->getCurrencyEUR())
            ->setRates(1)
            ->setDate('2024-01-01');

        $currencyRepository = $this->createMock(CurrencyRepository::class);
        $currencyByDateRepository = $this->createMock(CurrencyByDateRepository::class);

        $currencyByDateRepository
            ->expects($this->once())
            ->method('existsByCodeDate')
            ->with(self::EUR_CURRENCY, '2024-01-01')
            ->willReturn(true);

        $currencyByDateRepository
            ->expects($this->once())
            ->method('getByCodeDate')
            ->with(self::EUR_CURRENCY, '2024-01-01')
            ->willReturn($expected);

        $service = new CurrencyByDateService($currencyRepository, $currencyByDateRepository);
        $currencyByDate =
            $service->getCurrencyByDate(self::EUR_CURRENCY, '2024-01-01', $this->getCurrencyEUR());

        $this->assertEquals($expected, $currencyByDate);
    }

    public function testGetCurrencyByDate_NotExistsEmptyCurrency()
    {
        $expected = (new CurrencyByDate())
            ->setCurrency($this->getCurrencyEUR())
            ->setRates(1)
            ->setDate('2024-01-01');

        $currencyRepository = $this->createMock(CurrencyRepository::class);
        $currencyByDateRepository = $this->createMock(CurrencyByDateRepository::class);

        $currencyByDateRepository
            ->expects($this->once())
            ->method('existsByCodeDate')
            ->with(self::EUR_CURRENCY, '2024-01-01')
            ->willReturn(false);

        $currencyRepository
            ->expects($this->once())
            ->method('getByCode')
            ->with(self::EUR_CURRENCY)
            ->willReturn($this->getCurrencyEUR());

        $service = new CurrencyByDateService($currencyRepository, $currencyByDateRepository);
        $currencyByDate = $service->getCurrencyByDate(self::EUR_CURRENCY, '2024-01-01', null);

        $this->assertInstanceOf(CurrencyByDate::class, $currencyByDate);
        $this->assertInstanceOf(Currency::class, $currencyByDate->getCurrency());
        $this->assertEquals(self::EUR_CURRENCY, $currencyByDate->getCurrency()->getCode());
    }

    public function testGetCurrencyByDate_NotExistsWithCurrency()
    {
        $currencyRepository = $this->createMock(CurrencyRepository::class);
        $currencyByDateRepository = $this->createMock(CurrencyByDateRepository::class);

        $currencyByDateRepository
            ->expects($this->once())
            ->method('existsByCodeDate')
            ->with(self::EUR_CURRENCY, '2024-01-01')
            ->willReturn(false);

        $service = new CurrencyByDateService($currencyRepository, $currencyByDateRepository);
        $currencyByDate =
            $service->getCurrencyByDate(self::EUR_CURRENCY, '2024-01-01', $this->getCurrencyEUR());

        $this->assertInstanceOf(CurrencyByDate::class, $currencyByDate);
        $this->assertInstanceOf(Currency::class, $currencyByDate->getCurrency());
        $this->assertEquals(self::EUR_CURRENCY, $currencyByDate->getCurrency()->getCode());
    }

    public function testUpdateOrCreate_ExceptionEmptyCode()
    {
        $currencyRepository = $this->createMock(CurrencyRepository::class);
        $currencyByDateRepository = $this->createMock(CurrencyByDateRepository::class);
        $request = (new CurrencyByDateUpdateOrCreateRequest())
            ->setCode('')
            ->setRates(1)
            ->setDate('2024-01-01');

        $this->expectException(InvalidCurrencyByDateCreateOrUpdateDataException::class);

        $service = new CurrencyByDateService($currencyRepository, $currencyByDateRepository);
        $service->updateOrCreate($request);
    }

    public function testUpdateOrCreate_ExceptionEmptyRates()
    {
        $currencyRepository = $this->createMock(CurrencyRepository::class);
        $currencyByDateRepository = $this->createMock(CurrencyByDateRepository::class);
        $request = (new CurrencyByDateUpdateOrCreateRequest())
            ->setCode(self::EUR_CURRENCY)
            ->setRates(0)
            ->setDate('2024-01-01');

        $this->expectException(InvalidCurrencyByDateCreateOrUpdateDataException::class);

        $service = new CurrencyByDateService($currencyRepository, $currencyByDateRepository);
        $service->updateOrCreate($request);
    }

    public function testUpdateOrCreate_ExceptionEmptyDate()
    {
        $currencyRepository = $this->createMock(CurrencyRepository::class);
        $currencyByDateRepository = $this->createMock(CurrencyByDateRepository::class);
        $request = (new CurrencyByDateUpdateOrCreateRequest())
            ->setCode(self::EUR_CURRENCY)
            ->setRates(1)
            ->setDate('');

        $this->expectException(InvalidCurrencyByDateCreateOrUpdateDataException::class);

        $service = new CurrencyByDateService($currencyRepository, $currencyByDateRepository);
        $service->updateOrCreate($request);
    }

    public function testUpdateOrCreate_Success()
    {
        $currencyRepository = $this->createMock(CurrencyRepository::class);
        $currencyByDateRepository = $this->createMock(CurrencyByDateRepository::class);
        $currencyByDateRepository
            ->expects($this->once())
            ->method('saveAndCommit');

        $request = (new CurrencyByDateUpdateOrCreateRequest())
            ->setCode(self::EUR_CURRENCY)
            ->setRates(1)
            ->setDate('2024-01-01');

        $service = new CurrencyByDateService($currencyRepository, $currencyByDateRepository);
        $currencyByDate = $service->updateOrCreate($request, $this->getCurrencyEUR());

        $this->assertInstanceOf(CurrencyByDate::class, $currencyByDate);
        $this->assertInstanceOf(Currency::class, $currencyByDate->getCurrency());
        $this->assertEquals(self::EUR_CURRENCY, $currencyByDate->getCurrency()->getCode());
        $this->assertEquals(1, $currencyByDate->getCurrency()->getRates());
        $this->assertEquals('2024-01-01', $currencyByDate->getDate());
    }

    private function getCurrencyEUR(): Currency
    {
        return (new Currency())
            ->setCode(self::EUR_CURRENCY)
            ->setRates(1)
            ->setCreatedAt(new \DateTimeImmutable('2024-01-01 12:00:00'))
            ->setUpdatedAt(new \DateTimeImmutable('2024-01-01 12:00:00'));
    }
}
