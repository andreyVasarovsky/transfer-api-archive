<?php

namespace App\Tests\Service;

use App\Entity\Account;
use App\Entity\Client;
use App\Entity\Currency;
use App\Exception\CurrencyIsNotFoundException;
use App\Exception\InvalidOperationException;
use App\Exception\NotEnoughBalanceException;
use App\Exception\TransferInvalidRecipientAccountCurrencyNotMatchException;
use App\Exception\TransferRecipientAccountIsNotExistsException;
use App\Exception\TransferSenderAccountIsNotExistsException;
use App\Helpers\Currency as CurrencyHelper;
use App\Entity\Transaction;
use App\Entity\TransactionStatus;
use App\Exception\AccountNotFoundException;
use App\Mapper\TransactionMapper;
use App\Model\IdResponse;
use App\Model\TransactionListResponse;
use App\Model\TransferFundsRequest;
use App\Repository\AccountRepository;
use App\Repository\CurrencyRepository;
use App\Repository\TransactionRepository;
use App\Repository\TransactionStatusRepository;
use App\Service\AccountService;
use PHPUnit\Framework\TestCase;
use ReflectionProperty;

class AccountServiceTest extends TestCase
{

    public function testTransfer_Success()
    {
        $currencyHelper = $this->createMock(CurrencyHelper::class);
        $accountRepository = $this->createMock(AccountRepository::class);
        $currencyRepository = $this->createMock(CurrencyRepository::class);
        $transactionRepository = $this->createMock(TransactionRepository::class);
        $transactionStatusRepository = $this->createMock(TransactionStatusRepository::class);

        $request = (new TransferFundsRequest())
            ->setAmount(1)
            ->setSenderId(1)
            ->setCurrency('EUR')
            ->setRecipientId(2);

        $accountRepository->expects($this->exactly(2))->method('existsById')
            ->willReturnOnConsecutiveCalls(true, true);

        $currencyRepository
            ->expects($this->once())->method('existsByCode')->with($request->getCurrency())
            ->willReturn(true);

        $accountRepository->expects($this->exactly(2))->method('getById')
            ->willReturnOnConsecutiveCalls(
                (new Account())->setCurrency((new Currency())->setCode($request->getCurrency())),
                (new Account())->setCurrency((new Currency())->setCode($request->getCurrency()))->setBalance(1),
            );

        $currencyHelper->expects($this->once())->method('getAmount')->willReturn(floatval(1));
        $currencyHelper->expects($this->once())->method('getRatesByDate')->willReturn(floatval(1));
        $transactionStatusRepository->expects($this->once())->method('getByTitle')->willReturn(new TransactionStatus());
        $transactionRepository->expects($this->once())->method('saveAndCommit')->willReturn(10000);
        $accountRepository->expects($this->once())->method('decreaseBalance');
        $accountRepository->expects($this->once())->method('increaseBalance');

        $response = (new AccountService($transactionStatusRepository, $transactionRepository, $accountRepository, $currencyRepository, $currencyHelper))
            ->transfer($request);

        $this->assertEquals(new IdResponse(10000), $response);
    }

    public function testTransfer_NotEnoughBalanceException()
    {
        $currencyHelper = $this->createMock(CurrencyHelper::class);
        $accountRepository = $this->createMock(AccountRepository::class);
        $currencyRepository = $this->createMock(CurrencyRepository::class);
        $transactionRepository = $this->createMock(TransactionRepository::class);
        $transactionStatusRepository = $this->createMock(TransactionStatusRepository::class);

        $request = (new TransferFundsRequest())
            ->setAmount(1)
            ->setSenderId(1)
            ->setCurrency('EUR')
            ->setRecipientId(2);

        $accountRepository->expects($this->exactly(2))->method('existsById')
            ->willReturnOnConsecutiveCalls(true, true);

        $currencyRepository
            ->expects($this->once())->method('existsByCode')->with($request->getCurrency())
            ->willReturn(true);

        $accountRepository->expects($this->exactly(2))->method('getById')
            ->willReturnOnConsecutiveCalls(
                (new Account())->setCurrency((new Currency())->setCode($request->getCurrency())),
                (new Account())->setCurrency((new Currency())->setCode($request->getCurrency()))->setBalance(0),
            );

        $currencyHelper->expects($this->once())->method('getAmount')->willReturn(floatval(1));


        $this->expectException(NotEnoughBalanceException::class);

        (new AccountService($transactionStatusRepository, $transactionRepository, $accountRepository, $currencyRepository, $currencyHelper))
            ->transfer($request);
    }

    public function testTransfer_TransferInvalidRecipientAccountCurrencyNotMatchException()
    {
        $currencyHelper = $this->createMock(CurrencyHelper::class);
        $accountRepository = $this->createMock(AccountRepository::class);
        $currencyRepository = $this->createMock(CurrencyRepository::class);
        $transactionRepository = $this->createMock(TransactionRepository::class);
        $transactionStatusRepository = $this->createMock(TransactionStatusRepository::class);

        $request = (new TransferFundsRequest())
            ->setAmount(1)
            ->setSenderId(1)
            ->setCurrency('EUR')
            ->setRecipientId(2);

        $accountRepository->expects($this->exactly(2))->method('existsById')
            ->willReturnOnConsecutiveCalls(true, true);

        $accountRepository->expects($this->once())->method('getById')->with($request->getRecipientId())
            ->willReturn((new Account())->setCurrency((new Currency())->setCode('UN_EXISTED')));

        $currencyRepository
            ->expects($this->once())->method('existsByCode')->with($request->getCurrency())
            ->willReturn(true);

        $this->expectException(TransferInvalidRecipientAccountCurrencyNotMatchException::class);

        (new AccountService($transactionStatusRepository, $transactionRepository, $accountRepository, $currencyRepository, $currencyHelper))
            ->transfer($request);
    }

    public function testTransfer_InvalidOperationExceptionAmount()
    {
        $currencyHelper = $this->createMock(CurrencyHelper::class);
        $accountRepository = $this->createMock(AccountRepository::class);
        $currencyRepository = $this->createMock(CurrencyRepository::class);
        $transactionRepository = $this->createMock(TransactionRepository::class);
        $transactionStatusRepository = $this->createMock(TransactionStatusRepository::class);

        $request = (new TransferFundsRequest())
            ->setAmount(0)
            ->setSenderId(1)
            ->setCurrency('EUR')
            ->setRecipientId(2);

        $accountRepository->expects($this->exactly(2))->method('existsById')
            ->willReturnOnConsecutiveCalls(true, true);

        $currencyRepository
            ->expects($this->once())->method('existsByCode')->with($request->getCurrency())
            ->willReturn(true);

        $this->expectException(InvalidOperationException::class);

        (new AccountService($transactionStatusRepository, $transactionRepository, $accountRepository, $currencyRepository, $currencyHelper))
            ->transfer($request);
    }

    public function testTransfer_InvalidOperationException()
    {
        $currencyHelper = $this->createMock(CurrencyHelper::class);
        $accountRepository = $this->createMock(AccountRepository::class);
        $currencyRepository = $this->createMock(CurrencyRepository::class);
        $transactionRepository = $this->createMock(TransactionRepository::class);
        $transactionStatusRepository = $this->createMock(TransactionStatusRepository::class);

        $request = (new TransferFundsRequest())
            ->setAmount(1)
            ->setSenderId(1)
            ->setCurrency('EUR')
            ->setRecipientId(1);

        $accountRepository->expects($this->exactly(2))->method('existsById')
            ->willReturnOnConsecutiveCalls(true, true);

        $currencyRepository
            ->expects($this->once())->method('existsByCode')->with($request->getCurrency())
            ->willReturn(true);

        $this->expectException(InvalidOperationException::class);

        (new AccountService($transactionStatusRepository, $transactionRepository, $accountRepository, $currencyRepository, $currencyHelper))
            ->transfer($request);
    }

    public function testTransfer_CurrencyIsNotFoundException()
    {
        $currencyHelper = $this->createMock(CurrencyHelper::class);
        $accountRepository = $this->createMock(AccountRepository::class);
        $currencyRepository = $this->createMock(CurrencyRepository::class);
        $transactionRepository = $this->createMock(TransactionRepository::class);
        $transactionStatusRepository = $this->createMock(TransactionStatusRepository::class);

        $request = (new TransferFundsRequest())
            ->setAmount(1)
            ->setSenderId(1)
            ->setCurrency('EUR')
            ->setRecipientId(2);

        $accountRepository
            ->expects($this->exactly(2))
            ->method('existsById')
            ->willReturnOnConsecutiveCalls(true, true);

        $currencyRepository
            ->expects($this->once())
            ->method('existsByCode')
            ->with($request->getCurrency())
            ->willReturn(false);

        $this->expectException(CurrencyIsNotFoundException::class);

        (new AccountService($transactionStatusRepository, $transactionRepository, $accountRepository, $currencyRepository, $currencyHelper))
            ->transfer($request);
    }

    public function testTransfer_TransferRecipientAccountIsNotExistsException()
    {
        $currencyHelper = $this->createMock(CurrencyHelper::class);
        $accountRepository = $this->createMock(AccountRepository::class);
        $currencyRepository = $this->createMock(CurrencyRepository::class);
        $transactionRepository = $this->createMock(TransactionRepository::class);
        $transactionStatusRepository = $this->createMock(TransactionStatusRepository::class);

        $request = (new TransferFundsRequest())
            ->setAmount(1)
            ->setSenderId(1)
            ->setCurrency('EUR')
            ->setRecipientId(2);

        $accountRepository
            ->expects($this->exactly(2))
            ->method('existsById')
            ->willReturnOnConsecutiveCalls(true, false);

        $this->expectException(TransferRecipientAccountIsNotExistsException::class);

        (new AccountService($transactionStatusRepository, $transactionRepository, $accountRepository, $currencyRepository, $currencyHelper))
            ->transfer($request);
    }

    public function testTransfer_TransferSenderAccountIsNotExistsException()
    {
        $currencyHelper = $this->createMock(CurrencyHelper::class);
        $accountRepository = $this->createMock(AccountRepository::class);
        $currencyRepository = $this->createMock(CurrencyRepository::class);
        $transactionRepository = $this->createMock(TransactionRepository::class);
        $transactionStatusRepository = $this->createMock(TransactionStatusRepository::class);

        $request = (new TransferFundsRequest())
            ->setAmount(1)
            ->setSenderId(1)
            ->setCurrency('EUR')
            ->setRecipientId(1);

        $accountRepository
            ->expects($this->once())
            ->method('existsById')
            ->with(1)
            ->willReturn(false);

        $this->expectException(TransferSenderAccountIsNotExistsException::class);

        (new AccountService($transactionStatusRepository, $transactionRepository, $accountRepository, $currencyRepository, $currencyHelper))
            ->transfer($request);
    }

    public function testGetTransactionsById_Exception()
    {
        $currencyHelper = $this->createMock(CurrencyHelper::class);
        $currencyRepository = $this->createMock(CurrencyRepository::class);
        $transactionRepository = $this->createMock(TransactionRepository::class);
        $transactionStatusRepository = $this->createMock(TransactionStatusRepository::class);

        $accountRepository = $this->createMock(AccountRepository::class);
        $accountRepository
            ->expects($this->once())
            ->method('existsById')
            ->with(1)
            ->willReturn(false);

        $this->expectException(AccountNotFoundException::class);

        (new AccountService($transactionStatusRepository, $transactionRepository, $accountRepository, $currencyRepository, $currencyHelper))
            ->getTransactionsById(1);
    }

    public function testGetTransactionsById_Success()
    {
        $currencyHelper = $this->createMock(CurrencyHelper::class);
        $currencyRepository = $this->createMock(CurrencyRepository::class);
        $transactionRepository = $this->createMock(TransactionRepository::class);
        $transactionStatusRepository = $this->createMock(TransactionStatusRepository::class);

        $currency = (new Currency())->setCode('EUR');
        $clientTo = (new Client())->setFirstname('Test 1')->setLastname('Test 1');
        $clientFrom = (new Client())->setFirstname('Test 2')->setLastname('Test 2');
        $accountTo = (new Account())->setClient($clientTo)->setCurrency($currency);
        $accountFrom = (new Account())->setClient($clientFrom)->setCurrency($currency);
        try {
            $property = new ReflectionProperty($accountTo, 'id');
            $property->setValue($accountTo, 1);
            $property = new ReflectionProperty($accountFrom, 'id');
            $property->setValue($accountFrom, 2);
        } catch (\ReflectionException $e) {
            $this->fail("Test can't reset static property");
        }

        $transaction = (new Transaction())
            ->setAccountFrom($accountFrom)
            ->setAccountTo($accountTo)
            ->setAmountFrom(10)
            ->setAmountTo(10)
            ->setStatus((new TransactionStatus())->setTitle('Test'))
            ->setCreatedAt(new \DateTimeImmutable('2024-01-01 00:00:00'));

        $accountRepository = $this->createMock(AccountRepository::class);
        $accountRepository
            ->expects($this->once())
            ->method('existsById')
            ->with(1)
            ->willReturn(true);
        $accountRepository
            ->expects($this->once())
            ->method('getTransactionsByAccountId')
            ->with(1, 1, 1)
            ->willReturn([$transaction]);

        $expected = TransactionMapper::map(1, [$transaction]);
        $expected = new TransactionListResponse($expected, 'Success', true);

        $received = (new AccountService($transactionStatusRepository, $transactionRepository, $accountRepository, $currencyRepository, $currencyHelper))
            ->getTransactionsById(1, [
                'offset' => 1,
                'limit' => 1
            ]);

        $this->assertEquals($expected, $received);
    }
}
