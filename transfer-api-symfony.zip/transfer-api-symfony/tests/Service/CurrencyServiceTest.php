<?php

namespace App\Tests\Service;

use App\Entity\Currency;
use App\Exception\InvalidCurrencyCreateOrUpdateDataException;
use App\Model\CurrencyUpdateOrCreateRequest;
use App\Repository\CurrencyRepository;
use App\Service\CurrencyService;
use Doctrine\ORM\EntityManagerInterface;
use PHPUnit\Framework\TestCase;

class CurrencyServiceTest extends TestCase
{
    const EUR_CURRENCY = 'EUR';

    public function testGetCurrency_Exists()
    {
        $expected = (new Currency())
            ->setCode(self::EUR_CURRENCY)
            ->setRates(1)
            ->setCreatedAt(new \DateTimeImmutable('2024-01-01 12:00:00'))
            ->setUpdatedAt(new \DateTimeImmutable('2024-01-01 12:00:00'));

        $currencyRepository = $this->createMock(CurrencyRepository::class);
        $currencyRepository
            ->expects($this->once())
            ->method('existsByCode')
            ->with(self::EUR_CURRENCY)
            ->willReturn(true);
        $currencyRepository
            ->expects($this->once())
            ->method('getByCode')
            ->with(self::EUR_CURRENCY)
            ->willReturn($expected);

        $entityManager = $this->createMock(EntityManagerInterface::class);

        $service = new CurrencyService($currencyRepository, $entityManager);
        $currency = $service->getCurrency(self::EUR_CURRENCY);

        $this->assertEquals($expected, $currency);
    }

    public function testGetCurrency_NotExists()
    {
        $currencyRepository = $this->createMock(CurrencyRepository::class);
        $currencyRepository
            ->expects($this->once())
            ->method('existsByCode')
            ->with(self::EUR_CURRENCY)
            ->willReturn(false);

        $entityManager = $this->createMock(EntityManagerInterface::class);

        $service = new CurrencyService($currencyRepository, $entityManager);
        $currency = $service->getCurrency(self::EUR_CURRENCY);

        $this->assertInstanceOf(Currency::class, $currency);
        $this->assertEquals(self::EUR_CURRENCY, $currency->getCode());
    }

    public function testUpdateOrCreate_ExceptionEmptyCode()
    {
        $currencyRepository = $this->createMock(CurrencyRepository::class);
        $entityManager = $this->createMock(EntityManagerInterface::class);
        $request = (new CurrencyUpdateOrCreateRequest())->setCode('')->setRates(1);

        $this->expectException(InvalidCurrencyCreateOrUpdateDataException::class);

        $service = new CurrencyService($currencyRepository, $entityManager);
        $service->updateOrCreate($request);
    }

    public function testUpdateOrCreate_ExceptionEmptyRates()
    {
        $currencyRepository = $this->createMock(CurrencyRepository::class);
        $entityManager = $this->createMock(EntityManagerInterface::class);
        $request = (new CurrencyUpdateOrCreateRequest())->setCode(self::EUR_CURRENCY)->setRates(0);

        $this->expectException(InvalidCurrencyCreateOrUpdateDataException::class);

        $service = new CurrencyService($currencyRepository, $entityManager);
        $service->updateOrCreate($request);
    }

    public function testUpdateOrCreate_Success()
    {
        $currencyRepository = $this->createMock(CurrencyRepository::class);
        $currencyRepository
            ->expects($this->once())
            ->method('saveAndCommit');

        $entityManager = $this->createMock(EntityManagerInterface::class);

        $request = (new CurrencyUpdateOrCreateRequest())
            ->setCode(self::EUR_CURRENCY)
            ->setRates(1);

        $service = new CurrencyService($currencyRepository, $entityManager);
        $currency = $service->updateOrCreate($request);

        $this->assertInstanceOf(Currency::class, $currency);
        $this->assertEquals(self::EUR_CURRENCY, $currency->getCode());
        $this->assertEquals(1, $currency->getRates());
    }

    public function testResetRatesExcludeCodes_EmptyCodes()
    {
        $currencyRepository = $this->createMock(CurrencyRepository::class);
        $currencyRepository
            ->expects($this->once())
            ->method('getCodesExcludeCodes')
            ->with([])
            ->willReturn([]);

        $entityManager = $this->createMock(EntityManagerInterface::class);

        $service = new CurrencyService($currencyRepository, $entityManager);

        $this->assertEquals(0, $service->resetRatesExcludeCodes([]));
    }

    public function testResetRatesExcludeCodes_WithCodes()
    {
        $currencyRepository = $this->createMock(CurrencyRepository::class);
        $currencyRepository
            ->expects($this->once())
            ->method('getCodesExcludeCodes')
            ->with([self::EUR_CURRENCY])
            ->willReturn([(new Currency())->setCode('EUR')]);

        $entityManager = $this->createMock(EntityManagerInterface::class);
        $entityManager
            ->expects($this->once())
            ->method('persist')
            ->with((new Currency())->setCode('EUR')->setRates(0));

        $entityManager->expects($this->once())->method('flush');

        $service = new CurrencyService($currencyRepository, $entityManager);
        $this->assertEquals(1, $service->resetRatesExcludeCodes([self::EUR_CURRENCY]));
    }
}
