<?php

namespace App\Tests\Service;

use App\Entity\Account;
use App\Entity\Client;
use App\Entity\Currency;
use App\Exception\ClientNotFoundException;
use App\Model\AccountListResponse;
use App\Model\AccountResponse;
use App\Repository\ClientRepository;
use App\Service\ClientService;
use PHPUnit\Framework\TestCase;

class ClientServiceTest extends TestCase
{
    const EUR_CURRENCY = 'EUR';

    public function testGetAccountsById_Exception()
    {
        $clientRepository = $this->createMock(ClientRepository::class);
        $clientRepository
            ->expects($this->once())
            ->method('existsById')
            ->with(1)
            ->willReturn(false);

        $this->expectException(ClientNotFoundException::class);

        (new ClientService($clientRepository))->getAccountsById(1);
    }

    public function testGetAccountsById_Success()
    {
        $clientRepository = $this->createMock(ClientRepository::class);
        $clientRepository
            ->expects($this->once())
            ->method('existsById')
            ->with(1)
            ->willReturn(true);

        $clientRepository
            ->expects($this->once())
            ->method('getAccountsByClientId')
            ->with(1)
            ->willReturn([
                (new Account())
                    ->setClient($this->getClient())
                    ->setBalance(10)
                    ->setCurrency($this->getCurrencyEUR()),
            ]);

        $expected = new AccountListResponse([
            (new AccountResponse())
                ->setId(null)
                ->setBalance(10)
                ->setCurrency(self::EUR_CURRENCY)
        ], 'Success', true);

        $accountListResponse = (new ClientService($clientRepository))->getAccountsById(1);

        $this->assertEquals($expected, $accountListResponse);
    }

    private function getCurrencyEUR(): Currency
    {
        return (new Currency())
            ->setCode(self::EUR_CURRENCY)
            ->setRates(1)
            ->setCreatedAt(new \DateTimeImmutable('2024-01-01 12:00:00'))
            ->setUpdatedAt(new \DateTimeImmutable('2024-01-01 12:00:00'));
    }

    private function getClient(): Client
    {
        return (new Client())
            ->setEmail('test@test.lv')
            ->setFirstname('test')
            ->setLastname('testovs');
    }
}
