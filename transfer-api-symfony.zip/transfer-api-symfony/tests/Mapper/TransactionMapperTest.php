<?php

namespace App\Tests\Mapper;

use App\Entity\Account;
use App\Entity\Client;
use App\Entity\Currency;
use App\Entity\Transaction;
use App\Entity\TransactionStatus;
use App\Mapper\TransactionMapper;
use App\Model\TransactionResponse;
use PHPUnit\Framework\TestCase;
use ReflectionProperty;

class TransactionMapperTest extends TestCase
{

    public function testMap()
    {
        $clients = [
            (new Client())->setFirstname('Test 1')->setLastname('Test 1'),
            (new Client())->setFirstname('Test 2')->setLastname('Test 2'),
            (new Client())->setFirstname('Test 3')->setLastname('Test 3'),
            (new Client())->setFirstname('Test 4')->setLastname('Test 4'),
        ];
        $currency = (new Currency())->setCode('EUR');

        $accounts = [
            (new Account())->setClient($clients[0])->setCurrency($currency),
            (new Account())->setClient($clients[1])->setCurrency($currency),
            (new Account())->setClient($clients[2])->setCurrency($currency),
            (new Account())->setClient($clients[3])->setCurrency($currency),
        ];

        try {
            $property = new ReflectionProperty($accounts[0], 'id');
            $property->setValue($accounts[0], 1);
            $property = new ReflectionProperty($accounts[1], 'id');
            $property->setValue($accounts[1], 2);
            $property = new ReflectionProperty($accounts[2], 'id');
            $property->setValue($accounts[2], 3);
            $property = new ReflectionProperty($accounts[3], 'id');
            $property->setValue($accounts[3], 4);
        } catch (\ReflectionException $e) {
            $this->fail("Test can't reset static property");
        }


        $transactions = [
            (new Transaction())
                ->setAccountFrom($accounts[0])
                ->setAccountTo($accounts[1])
                ->setAmountFrom(10)
                ->setAmountTo(10)
                ->setStatus((new TransactionStatus())->setTitle('Test'))
                ->setCreatedAt(new \DateTimeImmutable('2024-01-01 00:00:00')),
            (new Transaction())
                ->setAccountFrom($accounts[2])
                ->setAccountTo($accounts[3])
                ->setAmountFrom(20)
                ->setAmountTo(20)
                ->setStatus((new TransactionStatus())->setTitle('Test 2'))
                ->setCreatedAt(new \DateTimeImmutable('2024-01-01 00:00:00'))
        ];

        $this->assertEquals(
            [
                (new TransactionResponse())
                    ->setId(null)
                    ->setType('sending')
                    ->setStatus('Test')
                    ->setAmount('-10.00')
                    ->setAccountFrom(1)
                    ->setAccountTo(2)
                    ->setClientFrom($clients[0]->getFullName())
                    ->setClientTo($clients[1]->getFullName())
                    ->setCurrencySent('EUR')
                    ->setCurrencyReceived('EUR')
                    ->setDate('2024-01-01 00:00:00')
                    ->setTimestamp(1704063600),
                (new TransactionResponse())
                    ->setId(null)
                    ->setType('sending')
                    ->setStatus('Test 2')
                    ->setAmount('-20.00')
                    ->setAccountFrom(3)
                    ->setAccountTo(4)
                    ->setClientFrom($clients[2]->getFullName())
                    ->setClientTo($clients[3]->getFullName())
                    ->setCurrencySent('EUR')
                    ->setCurrencyReceived('EUR')
                    ->setDate('2024-01-01 00:00:00')
                    ->setTimestamp(1704063600),

            ], TransactionMapper::map(null, $transactions));
    }
}
