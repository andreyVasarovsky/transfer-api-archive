<?php

namespace App\Tests\Mapper;

use App\Entity\Account;
use App\Entity\Currency;
use App\Mapper\AccountMapper;
use App\Model\AccountResponse;
use PHPUnit\Framework\TestCase;

class AccountMapperTest extends TestCase
{
    const EUR_CURRENCY = 'EUR';
    const USD_CURRENCY = 'USD';

    public function testMap()
    {
        $accounts = [
            (new Account())->setBalance(10)->setCurrency($this->getCurrencyEntity(self::EUR_CURRENCY)),
            (new Account())->setBalance(20)->setCurrency($this->getCurrencyEntity(self::USD_CURRENCY))
        ];

        $this->assertEquals([
            (new AccountResponse())
                ->setId(null)
                ->setBalance($accounts[0]->getBalance())
                ->setCurrency($accounts[0]->getCurrency()->getCode()),
            (new AccountResponse())
                ->setId(null)
                ->setBalance($accounts[1]->getBalance())
                ->setCurrency($accounts[1]->getCurrency()->getCode())
        ], (new AccountMapper())->map($accounts));
    }

    public function getCurrencyEntity(string $code): Currency
    {
        return (new Currency())->setCode($code);

    }
}
