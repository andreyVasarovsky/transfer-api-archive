<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20240210213944 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE account (id INT AUTO_INCREMENT NOT NULL, balance NUMERIC(15, 2) NOT NULL, updated_at DATETIME NOT NULL, created_at DATETIME NOT NULL, client_id INT NOT NULL, currency_code VARCHAR(3) DEFAULT NULL, INDEX IDX_7D3656A419EB6921 (client_id), INDEX IDX_7D3656A4FDA273EC (currency_code), UNIQUE INDEX client_currency (client_id, currency_code), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4');
        $this->addSql('CREATE TABLE client (id INT AUTO_INCREMENT NOT NULL, email VARCHAR(60) NOT NULL, firstname VARCHAR(60) NOT NULL, lastname VARCHAR(100) NOT NULL, created_at DATETIME NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4');
        $this->addSql('CREATE TABLE currency (code VARCHAR(3) NOT NULL, rates NUMERIC(15, 5) NOT NULL, updated_at DATETIME NOT NULL, created_at DATETIME NOT NULL, PRIMARY KEY(code)) DEFAULT CHARACTER SET utf8mb4');
        $this->addSql('CREATE TABLE currency_by_date (date VARCHAR(255) NOT NULL, rates NUMERIC(15, 5) NOT NULL, currency VARCHAR(3) NOT NULL, INDEX IDX_415894286956883F (currency), PRIMARY KEY(currency, date)) DEFAULT CHARACTER SET utf8mb4');
        $this->addSql('CREATE TABLE transaction (id INT AUTO_INCREMENT NOT NULL, amount_from NUMERIC(15, 2) NOT NULL, amount_to NUMERIC(15, 2) NOT NULL, rates NUMERIC(15, 5) NOT NULL, updated_at DATETIME NOT NULL, created_at DATETIME NOT NULL, account_from_id INT NOT NULL, account_to_id INT NOT NULL, status_id INT NOT NULL, INDEX IDX_723705D1B1E5CD43 (account_from_id), INDEX IDX_723705D16BA9314 (account_to_id), INDEX IDX_723705D16BF700BD (status_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4');
        $this->addSql('CREATE TABLE transaction_status (id INT AUTO_INCREMENT NOT NULL, title VARCHAR(15) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4');
        $this->addSql('CREATE TABLE user (id INT AUTO_INCREMENT NOT NULL, email VARCHAR(180) NOT NULL, roles JSON NOT NULL, password VARCHAR(255) NOT NULL, UNIQUE INDEX UNIQ_8D93D649E7927C74 (email), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4');
        $this->addSql('ALTER TABLE account ADD CONSTRAINT FK_7D3656A419EB6921 FOREIGN KEY (client_id) REFERENCES client (id)');
        $this->addSql('ALTER TABLE account ADD CONSTRAINT FK_7D3656A4FDA273EC FOREIGN KEY (currency_code) REFERENCES currency (code)');
        $this->addSql('ALTER TABLE currency_by_date ADD CONSTRAINT FK_415894286956883F FOREIGN KEY (currency) REFERENCES currency (code)');
        $this->addSql('ALTER TABLE transaction ADD CONSTRAINT FK_723705D1B1E5CD43 FOREIGN KEY (account_from_id) REFERENCES account (id)');
        $this->addSql('ALTER TABLE transaction ADD CONSTRAINT FK_723705D16BA9314 FOREIGN KEY (account_to_id) REFERENCES account (id)');
        $this->addSql('ALTER TABLE transaction ADD CONSTRAINT FK_723705D16BF700BD FOREIGN KEY (status_id) REFERENCES transaction_status (id)');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE account DROP FOREIGN KEY FK_7D3656A419EB6921');
        $this->addSql('ALTER TABLE account DROP FOREIGN KEY FK_7D3656A4FDA273EC');
        $this->addSql('ALTER TABLE currency_by_date DROP FOREIGN KEY FK_415894286956883F');
        $this->addSql('ALTER TABLE transaction DROP FOREIGN KEY FK_723705D1B1E5CD43');
        $this->addSql('ALTER TABLE transaction DROP FOREIGN KEY FK_723705D16BA9314');
        $this->addSql('ALTER TABLE transaction DROP FOREIGN KEY FK_723705D16BF700BD');
        $this->addSql('DROP TABLE account');
        $this->addSql('DROP TABLE client');
        $this->addSql('DROP TABLE currency');
        $this->addSql('DROP TABLE currency_by_date');
        $this->addSql('DROP TABLE transaction');
        $this->addSql('DROP TABLE transaction_status');
        $this->addSql('DROP TABLE user');
    }
}
